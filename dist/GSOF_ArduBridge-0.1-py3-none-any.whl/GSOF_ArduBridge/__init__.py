#!/usr/bin/env python 

# this is a wrapper module for different platform implementations
#
# (C) 2019 Guy Soffer <gsoffer@yahoo.com>

VERSION = '101'
